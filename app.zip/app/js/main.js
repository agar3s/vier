//@agar3s
data = loadByString(hero);
heroS = new Sprite(data);
powers = [];
for (j = 0; j < heroAnimation.length; j++) {
  var ha = frames[heroAnimation[j]];
  heroS.addFrame(loadByString(ha));
};

heroElementColors = [25,115,205,295];
Power = function(type){
  var m = this;
  m.data = loadByString(fire);
  m.sprite = new Sprite(m.data);
  m.outside = 0;
  m.sprite.color = heroS.color;
  m.sprite.x = heroS.x+8*3;
  m.sprite.y = heroS.y;
  m.sprite.vx = heroS.direction?8:-8;
  m.sprite.direction = heroS.direction;
  m.updateX= function(){
    m.sprite.updateX();
    m.outside = m.sprite.x>1000 || m.sprite.x<-10;
  }
}

HeroT = function(spr){
  var m = this;
  m.sprite = spr;
  m.element = 0;
  m.coldown = 16;
  m.currentColor = heroElementColors[m.element];
  m.sprite.color = 'hsl('+m.currentColor+',100%, 50%)';
  m.incColor = 0;
  m.changeColor = function(inc){
    m.incColor=inc;
    //heroElementColors[m.element];
  }
  m.next = function(){
    if(++m.element>3) m.element=0;
    m.incColor=5;
    //m.changeColor(1);
    keyMap-=16;
  }
  m.prev = function(){
    if(--m.element<0) m.element=3;
    keyMap-=64;
    m.incColor=-5;
    //m.changeColor(-1);
  }
  m.power = function(){
    if(m.coldown<=0){
      powers.push(new Power(0));
      m.coldown = 16;
    }
  }
  m.update = function(){
    m.currentColor+=m.incColor;
    if(m.currentColor<0) m.currentColor=355;
    if(m.currentColor>355) m.currentColor=0;
    if(m.currentColor!=heroElementColors[m.element]){
      m.sprite.color = 'hsl('+m.currentColor+',100%, 50%)';
    }else{
      m.incColor = 0;
    }
    if(--m.coldown<0) m.coldown=0;
  }
  m.manage= function(){
    if(keyMap&16) m.next();
    if(keyMap&64) m.prev();
    if(keyMap&1) m.sprite.left();
    if(keyMap&4) m.sprite.right();
    if(keyMap&8) m.sprite.down();
    if(keyMap&2) m.sprite.up();
    if(keyMap&128) m.sprite.jump();
    if(keyMap&32) m.power();
  }
}

data = loadByString(fire);
firexx = new Sprite(data);
firexx.color = '#E60';
myhero = new HeroT(heroS);

function cleanSpace(){
  ctx.fillStyle='#333';
  ctx.fillRect(0,0,800,600);
}

var platforms = [];
platforms.push(new Platform(12,400,240));
platforms.push(new Platform(600,400,240));
platforms.push(new Platform(320,336,240));
platforms.push(new Platform(120,520,60));
platforms.push(new Platform(150,500,240));

var loop = 0;
function gameLoop() {
  cleanSpace();
  firexx.drawCharacter(3);
  heroS.drawCharacter(6);
  heroS.accelerateY(1);
  heroS.update();
  myhero.update();
  for(i = 0; i < platforms.length; i++) {
    platforms[i].draw();
    platforms[i].collides();
  }
  for (var j = powers.length - 1; j >= 0; j--) {
    //powers[j].sprite.accelerateY(1);
    powers[j].updateX();
    powers[j].sprite.drawCharacter(3);
    if(loop%4==0){
      powers[j].sprite.rotate()
    }
    if(powers[j].outside){
      powers.splice(j, 1);
    }
  }

  if(loop%8==0){
    firexx.rotate();
    loop=0;
  }
  firexx.updateX();
  myhero.manage();
  if(loop%3==0){
    heroS.animate();
  }
  loop++;
  requestAnimationFrame(gameLoop);
}

requestAnimationFrame(gameLoop);