window.fire = '{f{g{h{i{u!$%056?@ABFORV`bcefostu~,';
window.hero  = '{${5{F{H{I{W{X{Y{h"#13@CPS`bcdrt~-~/~=~?~M~O~\\~]~_~`';

window.frames = [
  '{E{4{3{5{$',
  '{G{Y{I',
  '{5{${E{4{3',
  '~0~,{g{6{&~/~-{H{F{5{$',
  '~@~<spBA~?~=db@1{X{6{&',
  '~l~k~LaQ4${X{H~]~Mp`PA3{W{G',
  '{i{Y{I{X{H',
  '5%{j{Z4${i{Y',
  '{J{I',
  '~]~M`P@4321{k{[{X{W{K~l~k~LaQB5#"{j{Z{J',
  '~?~=db$#"{j{<~@~<s42%{k',
  '~/~-{L{H{G{=~0~,{h{g{K{<'
];
window.heroAnimation = [0,1,2,3,4,5,6,7,8,9,10,11,11,10,9,8,7,6,5,4,3,2,1,0];