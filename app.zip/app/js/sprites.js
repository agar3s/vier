window.fire = '{f{g{h{i{u!$%056?@ABFORV`bcefostu~,';
window.hero  = '{H{I{X{Y"#$134ACEQSVacdsu~.~1~=~@~M~P~]~^~`~a';

window.frames = [
  '',
  '~A~>~0tqfUD2{i{h~@~=~1udVE1$#"{I{H'
];
window.heroAnimation = [0,0,0,0,0,0,0,0,0,1];
