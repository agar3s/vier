window.doc = document;
doc.get = doc.getElementById;
var canvas = doc.get('c'), ctx = canvas.getContext('2d'), pixelSize = 4, i,j,ppp=16, pp1=15;